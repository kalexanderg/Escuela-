﻿namespace BL.Escuela
{
   // public class Usuario
   // {
     //   internal string contrasena;

     //   public string Contrasena { get; internal set; }
     //   public string Nombre { get; internal set; }
  //  }
}