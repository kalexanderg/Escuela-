﻿namespace BL.Escuela
{
    internal class Contexto
    {
        public object Estudiantes { get; internal set; }
    }
}